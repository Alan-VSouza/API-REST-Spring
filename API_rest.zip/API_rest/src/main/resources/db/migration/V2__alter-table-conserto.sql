ALTER TABLE consertos ADD COLUMN veiculo_cor VARCHAR(20);
