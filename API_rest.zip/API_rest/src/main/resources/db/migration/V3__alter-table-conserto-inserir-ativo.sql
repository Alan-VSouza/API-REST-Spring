alter table consertos add ativo tinyint;

update consertos set ativo = 1;